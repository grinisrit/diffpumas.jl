#!/usr/bin/env python3
"""Two-panel descriptive convergence figure from independently reviewed outputs."""
import argparse,csv,hashlib,json,tomllib
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def verified_run(root):
    end=json.loads((root/'end_status.json').read_text())
    if not all(end[k] for k in ('execution_completed','source_unchanged','runtime_unchanged')):raise ValueError('Incomplete or changed run')
    for name,digest in end['output_sha256'].items():
        if sha(root/name)!=digest:raise ValueError(f'Output digest mismatch: {name}')
    return end

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evidence',type=Path,required=True);p.add_argument('--review',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.output.exists():raise ValueError('Use a fresh figure output directory')
    inputs=[Path(__file__).resolve()]
    for name in ('diagnostic_run','polish_run','polish_v2_run'):
        verified_run(a.evidence/name);inputs.extend([a.evidence/name/'end_status.json',a.evidence/name/'execution.json'])
    verified_run(a.review);inputs.extend([a.review/'end_status.json',a.review/'execution.json',a.review/'results/review.toml'])
    diagnostic=a.evidence/'diagnostic_run/results/directional_checks.csv';first=a.evidence/'polish_run/results/final.toml';last=a.evidence/'polish_v2_run/results/final.toml';qp=a.evidence/'polish_v2_run/results/polish_state.toml'
    inputs.extend([diagnostic,first,last,qp])
    one=tomllib.load(first.open('rb'));two=tomllib.load(last.open('rb'));review=tomllib.load((a.review/'results/review.toml').open('rb'));samples=tomllib.load(qp.open('rb'))['sample_records']
    assert two['objective']==review['trial']['objective'] and two['selected_branch_projected_gradient']==review['selected_branch_pg']
    assert two['objective']==review['expected_objective'] and review['absolute_trial_discrepancy']==0
    assert not two['generalized_stationarity_certified'] and not two['selected_branch_pg_tolerance_met']
    rows=list(csv.DictReader(diagnostic.open()));steps=[1e-5,1e-6,1e-7,1e-8]
    slopes={}
    for sign in (-1,1):
        vals=[]
        for h in steps:
            r=next(x for x in rows if x['direction']==f'coordinate_375_{sign}' and float(x['step'])==h)
            vals.append(sign*float(r['slope']))
        slopes[sign]=vals
    endpoints=[('Frozen',one['initial_objective'],one['initial_projected_gradient']),('First polish',one['objective'],one['selected_branch_projected_gradient']),('Reduced polish',two['objective'],two['selected_branch_projected_gradient'])]
    baseline=endpoints[0][1]
    plt.rcParams.update({'font.size':11,'axes.labelsize':11,'axes.titlesize':12,'figure.facecolor':'white','savefig.facecolor':'white','pdf.fonttype':42})
    fig,(ax,tabax)=plt.subplots(2,1,figsize=(7.2,6.1),gridspec_kw={'height_ratios':[1.2,1]},layout='constrained')
    ax.plot(steps,slopes[-1],'-o',color='#28649a',label=r'$D_-(h)=[F(w)-F(w-he_{375})]/h$')
    ax.plot(steps,slopes[1],'-s',color='#b65d27',label=r'$D_+(h)=[F(w+he_{375})-F(w)]/h$')
    ax.axhline(0,color='#777777',lw=.8,ls='--');ax.set_xscale('log');ax.set_xlim(1.4e-5,.75e-8);ax.set_ylim(-.0055,.006)
    ax.set_xticks(steps);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,_:f'{v:.3f}'))
    ax.set(xlabel='Feasible coordinate displacement h',ylabel='Signed finite objective secant',title='(a) Coordinate 375 at the frozen endpoint')
    ax.grid(alpha=.2);ax.legend(loc='center right',frameon=True,fontsize=10)
    ax.text(.02,.96,'Both tested perturbations raise F\nFinite secants do not certify stationarity',transform=ax.transAxes,va='top',fontsize=10,color='#333333')
    tabax.set_axis_off();tabax.set_title('(b) Small exact decreases; branch criterion remains unmet',pad=9)
    cells=[[label,f'{baseline-objective:.5e}',f'{pg:.8f}'] for label,objective,pg in endpoints]
    table=tabax.table(cellText=cells,colLabels=['Endpoint',r'$F_0-F$',r'$\|\mathrm{PG}_{\mathrm{branch}}\|_\infty$'],cellLoc='center',colLoc='center',bbox=[.04,.39,.92,.5])
    table.auto_set_font_size(False);table.set_fontsize(11)
    for (i,j),cell in table.get_celld().items():
        cell.set_edgecolor('#dddddd');cell.set_linewidth(.6)
        if i==0:cell.set_facecolor('#eaf0f5');cell.set_text_props(weight='bold')
    tabax.text(.5,.28,r'$F_0=100.59269073659428$; selected-branch tolerance $10^{-6}$: unmet.',ha='center',transform=tabax.transAxes,fontsize=10)
    tabax.text(.5,.13,'Total decrease < 10⁻⁷; no claimed improvement in physical reconstruction.',ha='center',transform=tabax.transAxes,fontsize=10)
    tabax.text(.5,.02,'Solved finite-hull QPs do not certify generalized stationarity.',ha='center',transform=tabax.transAxes,fontsize=10,weight='bold')
    a.output.mkdir(parents=True)
    for suffix in ('pdf','png'):fig.savefig(a.output/f'fig_convergence_round3.{suffix}',dpi=220,bbox_inches='tight')
    plt.close(fig)
    record=dict(input_sha256={str(x.resolve()):sha(x) for x in inputs},steps=steps,left_signed_secants=slopes[-1],right_signed_secants=slopes[1],endpoints=[dict(label=l,objective=f,objective_gain=baseline-f,branch_pg=pg) for l,f,pg in endpoints],finite_qp=[{k:s[k] for k in ('radius','sampled_residual_l2','simplex_frank_wolfe_gap','simplex_converged','six_gradient_residual_l2')} for s in samples],scope='Finite-scale descriptive diagnostic; no generalized stationarity certificate or claimed reconstruction improvement.',output_sha256={x.name:sha(x) for x in a.output.iterdir()})
    (a.output/'figure_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
if __name__=='__main__':main()
